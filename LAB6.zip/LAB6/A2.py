import pandas as pd
import numpy as np

# Load dataset
data = pd.read_excel(r"C:\Users\jagan\OneDrive\Documents\sem4\ml\LAB6\ml_dataset.csv")

def gini_index(target):

    values, counts = np.unique(target, return_counts=True)

    prob = counts / counts.sum()

    gini = 1 - np.sum(prob ** 2)

    return gini


print("Gini Index:", gini_index(data['Conf Label']))