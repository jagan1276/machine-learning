import pandas as pd
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from sklearn.inspection import DecisionBoundaryDisplay

# Load dataset
data = pd.read_excel(r"C:\Users\jagan\OneDrive\Documents\sem4\ml\LAB6\ml_dataset.csv")

# Remove rows where Conf Label is missing
data = data.dropna(subset=['Conf Label'])

# Convert Conf Label to numeric
data['Conf Label'] = pd.to_numeric(data['Conf Label'], errors='coerce')
data = data.dropna(subset=['Conf Label'])

# Create two features from text
data['Text_Length'] = data['Text'].astype(str).apply(len)
data['Word_Count'] = data['Text'].astype(str).apply(lambda x: len(x.split()))

# Select two features
X = data[['Text_Length', 'Word_Count']]
y = data['Conf Label']

# Train Decision Tree
model = DecisionTreeClassifier(max_depth=4)
model.fit(X, y)

# Plot decision boundary
DecisionBoundaryDisplay.from_estimator(
    model,
    X,
    response_method="predict",
    xlabel="Text Length",
    ylabel="Word Count"
)

# Plot actual data points
plt.scatter(
    X['Text_Length'],
    X['Word_Count'],
    c=y,
    cmap='viridis',
    edgecolor='black'
)

plt.title("Decision Boundary using Decision Tree")
plt.show()