import pandas as pd
from sklearn.tree import DecisionTreeClassifier

# Load dataset
data = pd.read_excel(r"C:\Users\jagan\OneDrive\Documents\sem4\ml\LAB6\ml_dataset.csv")

# Remove rows where Conf Label is empty
data = data.dropna(subset=['Conf Label'])

# Convert text to numeric feature
data['Text_Length'] = data['Text'].astype(str).apply(len)

# Features and target
X = data[['Text_Length']]
y = data['Conf Label']

# Train model
model = DecisionTreeClassifier()
model.fit(X, y)

print("Decision Tree Model Built Successfully")