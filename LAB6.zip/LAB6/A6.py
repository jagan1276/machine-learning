import pandas as pd
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier, plot_tree

# Load dataset
data = pd.read_excel(r"C:\Users\jagan\OneDrive\Documents\sem4\ml\LAB6\ml_dataset.csv")

# Remove rows where Conf Label is missing
data = data.dropna(subset=['Conf Label'])

# Convert label to numeric
data['Conf Label'] = pd.to_numeric(data['Conf Label'], errors='coerce')

# Remove rows again if conversion created NaN
data = data.dropna(subset=['Conf Label'])

# Convert text column into numeric feature
data['Text_Length'] = data['Text'].astype(str).apply(len)

# Define features and target
X = data[['Text_Length']]
y = data['Conf Label']

# Train Decision Tree
model = DecisionTreeClassifier()
model.fit(X, y)

# Plot the Decision Tree
plt.figure(figsize=(16,10))

plot_tree(
    model,
    feature_names=['Text_Length'],
    class_names=True,
    filled=True,
    rounded=True
)

plt.title("Decision Tree Visualization")

plt.show()