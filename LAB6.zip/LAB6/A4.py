import pandas as pd

data = pd.read_excel(r"C:\Users\jagan\OneDrive\Documents\sem4\ml\LAB6\ml_dataset.csv")

data['Text_Length'] = data['Text'].astype(str).apply(len)

def equal_width_binning(column, bins=4):
    min_val = column.min()
    max_val = column.max()
    width = (max_val - min_val) / bins
    return ((column - min_val) // width).astype(int)

data['Text_Length_Binned'] = equal_width_binning(data['Text_Length'],4)

print(data[['Text_Length','Text_Length_Binned']].head())