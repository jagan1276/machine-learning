import pandas as pd
import numpy as np

data = pd.read_excel(r"C:\Users\jagan\OneDrive\Documents\sem4\ml\LAB6\ml_dataset.csv")

data['Text_Length'] = data['Text'].astype(str).apply(len)

def entropy(target):
    values, counts = np.unique(target, return_counts=True)
    prob = counts / counts.sum()
    return -np.sum(prob * np.log2(prob))

def information_gain(data, feature, target):
    total_entropy = entropy(data[target])
    values, counts = np.unique(data[feature], return_counts=True)

    weighted_entropy = 0
    for v, c in zip(values, counts):
        subset = data[data[feature] == v]
        weighted_entropy += (c/len(data)) * entropy(subset[target])

    return total_entropy - weighted_entropy

gain = information_gain(data, 'Text_Length', 'Conf Label')
print("Information Gain:", gain)