import pandas as pd
import numpy as np

# Load dataset
data = pd.read_excel(r"C:\Users\jagan\OneDrive\Documents\sem4\ml\LAB6\ml_dataset.csv")

# Entropy function
def entropy(target):

    values, counts = np.unique(target, return_counts=True)

    prob = counts / counts.sum()

    entropy_value = -np.sum(prob * np.log2(prob))

    return entropy_value


print("Entropy:", entropy(data['Conf Label']))